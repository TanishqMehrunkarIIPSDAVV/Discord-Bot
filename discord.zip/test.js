const path = require('node:path');
const d=path.basename(path.dirname(__filename));
console.log(path);